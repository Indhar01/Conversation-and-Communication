# webapp-practice

create evironment by
 >>virtualenv venv

 And the venv file is not added in this because of file limit
